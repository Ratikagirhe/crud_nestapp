export class BookService {
  // add book
  addbook(): string {
    return 'This book is added';
  }

  // update book
  updatebook(): string {
    return 'This book is updated';
  }

  // delete book
  deletebook(): string {
    return 'This book is deleted';
  }

  // find all book
  findbook(): string {
    return 'Find all';
  }
}
